
import React, { useState, useCallback, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductCard from './components/ProductCard';
import StylistAI from './components/StylistAI';
import CartSidebar from './components/CartSidebar';
import { PRODUCTS } from './constants';
import { Product, CartItem, Category } from './types';

const App: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [vaultAccessed, setVaultAccessed] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Manage body scroll based on state
  useEffect(() => {
    if (!vaultAccessed && !isTransitioning) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  }, [vaultAccessed, isTransitioning]);

  const handleEnterVault = () => {
    setIsTransitioning(true);
    // Sophisticated staggered transition
    setTimeout(() => {
      setVaultAccessed(true);
      window.scrollTo({ top: 0, behavior: 'instant' });
      setTimeout(() => {
        setIsTransitioning(false);
      }, 800);
    }, 1200); 
  };

  const handleExitVault = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setVaultAccessed(false);
      setActiveCategory('All');
      window.scrollTo({ top: 0, behavior: 'instant' });
      setTimeout(() => {
        setIsTransitioning(false);
      }, 800);
    }, 1200);
  };

  const handleCategorySelect = (category: string) => {
    if (!vaultAccessed) {
      handleEnterVault();
    }
    setActiveCategory(category);
  };

  const addToCart = useCallback((product: Product) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id);
      if (existing) {
        return prev.map(i => i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  }, []);

  const removeFromCart = useCallback((id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  }, []);

  const filteredProducts = activeCategory === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  const categories = ['All', ...Object.values(Category)];

  return (
    <div className="min-h-screen relative">
      {/* Luxury Entry Wipe Layers */}
      <div className={`iris-wipe ${isTransitioning ? 'active' : ''}`}></div>
      <div className={`dark-iris ${isTransitioning ? 'active' : ''}`}></div>

      <Navbar 
        onOpenCart={() => setIsCartOpen(true)} 
        cartCount={cart.length} 
        vaultAccessed={vaultAccessed}
        onExitVault={handleExitVault}
        onCategorySelect={handleCategorySelect}
      />
      
      <main className="relative">
        {/* Only show Hero if vault not accessed */}
        <div className={`transition-all duration-[1.5s] ${vaultAccessed ? 'opacity-0 scale-105 pointer-events-none absolute inset-0 h-screen' : 'opacity-100 scale-100'}`}>
          <Hero onEnter={handleEnterVault} isVaultAccessed={vaultAccessed} />
        </div>

        {/* Collection Section */}
        {vaultAccessed && (
          <section 
            id="collection-feed"
            className={`py-40 px-6 md:px-12 max-w-[1800px] mx-auto transition-all duration-[2s] ${vaultAccessed && !isTransitioning ? 'opacity-100' : 'opacity-0 translate-y-20'}`}
          >
            <div className="flex flex-col md:flex-row items-end justify-between mb-32 gap-12">
              <div className="animate-fade-in">
                <span className="text-white/20 text-[11px] tracking-[1em] uppercase font-bold mb-6 block">Collection_Manifest</span>
                <h2 className="font-syncopate text-5xl md:text-9xl font-bold tracking-tighter platinum-gradient uppercase">The Lab</h2>
              </div>
              
              <div className="flex flex-wrap gap-x-10 gap-y-6">
                {categories.map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`text-[10px] tracking-[0.5em] uppercase font-bold transition-all px-6 py-3 border-b border-white/5 hover:border-white/20 ${
                      activeCategory === cat 
                        ? 'text-white border-white/40' 
                        : 'text-white/20'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-16 gap-y-40">
              {filteredProducts.map((product, index) => (
                <div 
                  key={product.id} 
                  className={`reveal-item ${vaultAccessed && !isTransitioning ? 'active' : ''}`}
                  style={{ transitionDelay: `${index * 100 + 100}ms` }}
                >
                  <ProductCard 
                    product={product} 
                    onAddToCart={addToCart} 
                  />
                </div>
              ))}
            </div>

            {/* Membership Section within Vault */}
            <section className="mt-80 px-6 md:px-0">
               <div className="max-w-[1800px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-40 items-center">
                  <div className="reveal-item active" style={{ transitionDelay: '500ms' }}>
                     <span className="text-white/20 text-[12px] tracking-[1em] uppercase font-bold mb-10 block">Priority Protocol</span>
                     <h2 className="font-syncopate text-6xl md:text-8xl font-bold text-white mb-14 uppercase leading-[0.9]">
                        Lexan<br />
                        <span className="italic platinum-gradient">Identity</span>
                     </h2>
                     <p className="text-white/30 text-xl leading-relaxed max-w-xl mb-20 font-light tracking-[0.1em]">
                        Digital ownership for the modern vanguard. Access exclusive releases and prototype research by synchronizing your profile.
                     </p>
                     <button 
                        onClick={() => alert("Identity sync protocol initiated. Awaiting biometric confirmation...")}
                        className="group relative px-16 py-7 border border-white/20 overflow-hidden"
                     >
                        <div className="absolute inset-0 bg-white scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-500"></div>
                        <span className="relative z-10 text-white group-hover:text-black text-[11px] tracking-[0.6em] font-black uppercase">
                           Apply for Sync
                        </span>
                     </button>
                  </div>
                  <div className="relative group reveal-item active" style={{ transitionDelay: '700ms' }}>
                     <div className="aspect-[4/5] overflow-hidden grayscale brightness-50 group-hover:brightness-100 transition-all duration-[2s]">
                        <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1500&auto=format&fit=crop" className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-[3s]" alt="The Vault" />
                     </div>
                     <div className="absolute -top-10 -right-10 font-syncopate text-[200px] text-white/5 pointer-events-none select-none">LX</div>
                  </div>
               </div>
            </section>
          </section>
        )}
      </main>

      {/* Footer */}
      {vaultAccessed && (
        <footer className={`bg-[#030303] py-40 px-6 md:px-12 border-t border-white/5 transition-opacity duration-1000 ${vaultAccessed && !isTransitioning ? 'opacity-100' : 'opacity-0'}`}>
          <div className="max-w-[1800px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-32">
            <div className="col-span-1">
              <h2 className="font-syncopate text-3xl font-bold platinum-gradient tracking-[0.6em] mb-12 cursor-pointer" onClick={handleExitVault}>LEXAN</h2>
              <p className="text-[10px] tracking-[0.3em] text-white/20 uppercase font-bold leading-relaxed">
                Pioneering digital material science since 2025. <br />Hand-finished in decentralized ateliers.
              </p>
            </div>
            <div className="flex flex-col gap-8">
               <h5 className="text-[10px] tracking-[0.5em] text-white/50 uppercase font-bold">Archives</h5>
               <div className="flex flex-col gap-4 text-[11px] text-white/20 font-bold tracking-[0.2em] uppercase">
                  <a href="#" onClick={(e) => { e.preventDefault(); handleCategorySelect(Category.THE_ARCHIVES); }} className="hover:text-white transition-all">Season_01</a>
                  <a href="#" onClick={(e) => { e.preventDefault(); handleCategorySelect(Category.THE_ARCHIVES); }} className="hover:text-white transition-all">Season_02</a>
                  <a href="#" onClick={(e) => { e.preventDefault(); handleCategorySelect(Category.THE_ARCHIVES); }} className="hover:text-white transition-all">Beta_Drops</a>
               </div>
            </div>
            <div className="flex flex-col gap-8">
               <h5 className="text-[10px] tracking-[0.5em] text-white/50 uppercase font-bold">System</h5>
               <div className="flex flex-col gap-4 text-[11px] text-white/20 font-bold tracking-[0.2em] uppercase">
                  <a href="#" onClick={(e) => { e.preventDefault(); alert("Access Denied: High-Level Encryption Active."); }} className="hover:text-white transition-all">Privacy_Protocol</a>
                  <a href="#" onClick={(e) => { e.preventDefault(); alert("Verification required via LEX Concierge."); }} className="hover:text-white transition-all">Authentication</a>
                  <a href="#" onClick={(e) => { e.preventDefault(); alert("All nodes operative. Connection stable."); }} className="hover:text-white transition-all">Node_Status</a>
               </div>
            </div>
            <div>
               <h5 className="text-[10px] tracking-[0.5em] text-white/50 uppercase font-bold mb-10">Synchronize</h5>
               <form onSubmit={(e) => { e.preventDefault(); alert("Subscribing to AURA data stream..."); }} className="flex border-b border-white/10 pb-4 group">
                 <input type="email" required placeholder="TERMINAL@ID.COM" className="bg-transparent text-[11px] flex-1 outline-none font-bold tracking-[0.5em] text-white placeholder:text-white/5" />
                 <button type="submit" className="text-white/20 hover:text-white transition-all">SYNC</button>
               </form>
            </div>
          </div>
          <div className="max-w-[1800px] mx-auto mt-40 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-[8px] tracking-[0.8em] text-white/10 uppercase font-bold">
            <p>© 2025 LEXAN GLOBAL TERMINAL. ALL RIGHTS RESERVED.</p>
            <button onClick={handleExitVault} className="mt-8 md:mt-0 hover:text-white transition-colors">TERMINAL_RESET</button>
          </div>
        </footer>
      )}

      <StylistAI />
      <CartSidebar 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        items={cart} 
        onRemove={removeFromCart} 
      />
    </div>
  );
};

export default App;
