
import React from 'react';
import { X, Trash2, ArrowRight, Database } from 'lucide-react';
import { CartItem } from '../types';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemove: (id: string) => void;
}

const CartSidebar: React.FC<CartSidebarProps> = ({ isOpen, onClose, items, onRemove }) => {
  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleCheckout = () => {
    alert("TRANSACTION INITIATED.\n\nYour digital assets are being secured for physical manifestation.\nEncryption complete. Redirecting to secure node...");
    // In a real app, this would trigger navigation to a checkout page.
  };

  return (
    <div className={`fixed inset-0 z-[100] transition-opacity duration-700 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      <div className={`absolute right-0 top-0 h-full w-full max-w-lg bg-[#050505] border-l border-white/10 transition-transform duration-700 ease-out transform ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full p-12">
          <div className="flex items-center justify-between mb-20">
             <div className="flex items-center gap-4">
                <Database size={24} className="text-white/40" />
                <h2 className="font-syncopate text-3xl font-bold uppercase tracking-tighter silver-gradient">Manifest</h2>
             </div>
             <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
               <X size={24} strokeWidth={1} />
             </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-12 pr-4 custom-scrollbar">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center opacity-20">
                <p className="font-syncopate text-[10px] tracking-[0.5em] uppercase">Archive_Empty</p>
                <div className="w-12 h-[1px] bg-white mt-4"></div>
              </div>
            ) : (
              items.map((item) => (
                <div key={item.id} className="flex gap-8 group animate-fade-in border-b border-white/5 pb-8">
                  <div className="w-24 aspect-square bg-white/5 border border-white/10 overflow-hidden">
                    <img src={item.image} className="w-full h-full object-cover grayscale opacity-50 group-hover:opacity-100 transition-all" alt={item.name} />
                  </div>
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                         <h4 className="font-syncopate text-lg font-bold uppercase tracking-tight silver-gradient">{item.name}</h4>
                         <span className="text-[12px] font-bold text-white/40">₹{item.price.toLocaleString()}</span>
                      </div>
                      <p className="text-[9px] text-white/20 tracking-widest uppercase font-bold mt-2">{item.category}</p>
                    </div>
                    <div className="flex items-center justify-between mt-6">
                       <span className="text-[9px] font-bold text-white/10 tracking-[0.2em]">S_V01.manifest</span>
                       <button 
                         onClick={() => onRemove(item.id)}
                         className="text-white/20 hover:text-white transition-colors flex items-center gap-2 text-[9px] font-bold uppercase tracking-widest"
                       >
                         Purge <Trash2 size={12} />
                       </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {items.length > 0 && (
            <div className="mt-12 space-y-8 pt-12 border-t border-white/10">
              <div className="flex items-center justify-between font-syncopate">
                <span className="text-[10px] tracking-[0.5em] uppercase text-white/30 font-bold">Total_Value</span>
                <span className="text-3xl font-bold text-white">₹{total.toLocaleString()}</span>
              </div>
              <button 
                onClick={handleCheckout}
                className="group relative w-full overflow-hidden"
              >
                 <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                 <div className="relative z-10 w-full bg-transparent border border-white py-6 text-[11px] tracking-[0.6em] font-extrabold uppercase text-white group-hover:text-[#050505] transition-colors flex items-center justify-center gap-4">
                   Commit Acquisition <ArrowRight size={16} />
                 </div>
              </button>
              <div className="flex justify-center gap-8 text-[8px] font-bold text-white/20 tracking-[0.4em] uppercase">
                 <span>Secure_Node</span>
                 <span>P2P_Encryption</span>
                 <span>Vault_Locked</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartSidebar;
