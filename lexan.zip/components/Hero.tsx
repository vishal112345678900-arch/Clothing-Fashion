
import React from 'react';

interface HeroProps {
  onEnter: () => void;
  isVaultAccessed: boolean;
}

const Hero: React.FC<HeroProps> = ({ onEnter, isVaultAccessed }) => {
  return (
    <div className="relative h-screen w-full overflow-hidden flex items-center justify-center bg-[#030303]">
      {/* Cinematic Background */}
      <div 
        className={`absolute inset-0 bg-cover bg-center transition-all duration-[3s] ease-in-out ${isVaultAccessed ? 'scale-100 opacity-20 blur-sm' : 'scale-110 opacity-50 blur-0'}`}
        style={{ backgroundImage: `url('https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=2000&auto=format&fit=crop')` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#030303]"></div>
      </div>

      {/* Content */}
      <div className={`relative z-10 text-center px-6 transition-all duration-1000 ${isVaultAccessed ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'}`}>
        <div className="flex flex-col items-center mb-12">
            <span className="text-white/30 text-[10px] tracking-[1em] uppercase font-bold mb-6">Established 2025</span>
            <div className="w-[1px] h-16 bg-gradient-to-b from-white/0 via-white/20 to-white/0"></div>
        </div>
        
        <h2 className="font-syncopate text-6xl md:text-[160px] text-white font-bold leading-[0.8] tracking-[-0.06em] mb-16">
          LEXAN<br />
          <span className="platinum-gradient italic font-light text-4xl md:text-[80px] tracking-[0.2em] mt-4 block">DI_COUTURE</span>
        </h2>

        <button 
          onClick={onEnter}
          className="group relative px-20 py-6 overflow-hidden transition-all bg-white"
        >
          <div className="absolute inset-0 bg-black translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
          <span className="relative z-10 text-black group-hover:text-white text-[11px] tracking-[0.5em] font-black uppercase">
            Enter the Vault
          </span>
        </button>
      </div>

      {/* Aesthetic Tickers */}
      {!isVaultAccessed && (
        <div className="absolute bottom-20 left-12 flex flex-col gap-3">
          <div className="flex items-center gap-4">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span className="text-[9px] font-bold tracking-[0.4em] text-white/20 uppercase">System Ready</span>
          </div>
          <p className="text-[8px] tracking-[0.2em] text-white/10 max-w-[150px] uppercase font-mono">
            Accessing private manifest servers... encryption verified.
          </p>
        </div>
      )}
    </div>
  );
};

export default Hero;
