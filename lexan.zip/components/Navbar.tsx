
import React from 'react';
import { ShoppingBag, Search, Shield, ArrowLeft } from 'lucide-react';
import { Category } from '../types';

interface NavbarProps {
  onOpenCart: () => void;
  cartCount: number;
  vaultAccessed: boolean;
  onExitVault: () => void;
  onCategorySelect: (category: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ onOpenCart, cartCount, vaultAccessed, onExitVault, onCategorySelect }) => {
  const handleNavLink = (e: React.MouseEvent, category: string) => {
    e.preventDefault();
    onCategorySelect(category);
    const collection = document.getElementById('collection-feed');
    if (collection) {
      collection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed top-0 left-0 w-full z-[100] glass border-b border-white/5 py-6 px-6 md:px-12 transition-all duration-700">
      <div className="max-w-[1800px] mx-auto flex items-center justify-between">
        <div className="flex-1 flex items-center gap-8">
          <button 
            onClick={onExitVault}
            className={`flex items-center gap-3 group transition-all duration-500 ${vaultAccessed ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10 pointer-events-none'}`}
          >
            <div className="p-2 border border-white/10 rounded-full group-hover:bg-white group-hover:border-white transition-all">
              <ArrowLeft size={14} className="text-white group-hover:text-black transition-colors" />
            </div>
            <span className="text-[9px] tracking-[0.4em] font-bold text-white/40 group-hover:text-white transition-colors uppercase whitespace-nowrap">Go back to Entry page</span>
          </button>
          
          <h1 className={`font-syncopate text-2xl tracking-[0.5em] font-bold platinum-gradient transition-all duration-700 cursor-pointer`} onClick={onExitVault}>
            LEXAN
          </h1>
        </div>

        <div className="hidden lg:flex items-center space-x-16 text-[9px] tracking-[0.6em] font-bold uppercase text-white/40">
          <a href="#" onClick={(e) => handleNavLink(e, Category.THE_ARCHIVES)} className="hover:text-white transition-all hover:tracking-[0.8em]">Archives</a>
          <a href="#" onClick={(e) => handleNavLink(e, Category.THE_LABORATORY)} className="hover:text-white transition-all hover:tracking-[0.8em]">Laboratory</a>
          <a href="#" onClick={(e) => handleNavLink(e, Category.THE_VAULT)} className="hover:text-white transition-all hover:tracking-[0.8em]">The Vault</a>
        </div>

        <div className="flex-1 flex items-center justify-end space-x-10 text-white/60">
          <button className="hover:text-white transition-all" onClick={() => alert("Search Terminal_V1.0 is currently in secure maintenance mode.")}><Search size={16} strokeWidth={1.5} /></button>
          <button className="hover:text-white transition-all" onClick={() => alert("Security Protocol: Your identity is currently masked.")}><Shield size={16} strokeWidth={1.5} /></button>
          <button onClick={onOpenCart} className="flex items-center gap-4 group">
            <span className="text-[10px] font-syncopate text-white/30 group-hover:text-white transition-all">MANIFEST.{cartCount.toString().padStart(2, '0')}</span>
            <div className="relative">
              <ShoppingBag size={18} strokeWidth={1.5} className="group-hover:scale-110 transition-all" />
              {cartCount > 0 && <span className="absolute -top-1 -right-1 w-1.5 h-1.5 bg-white rounded-full"></span>}
            </div>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
