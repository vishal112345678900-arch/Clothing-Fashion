
import React from 'react';
import { Product } from '../types';
import { ChevronRight } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  const handleViewSpecs = () => {
    alert(`Accessing Specifications for ${product.name}...\n\nMaterial: ${product.description}\nPrice: ₹${product.price.toLocaleString()}\nStatus: Verified Secure.`);
  };

  return (
    <div className="group relative animate-fade-in flex flex-col h-full">
      {/* Cyber Frame */}
      <div className="relative aspect-[4/5] overflow-hidden bg-white/5 border border-white/10 group-hover:border-white/30 transition-all duration-700">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover grayscale opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-1000"
        />
        
        {/* Data Overlay */}
        <div className="absolute top-4 right-4 flex flex-col items-end gap-1">
           <span className="text-[8px] font-bold tracking-[0.2em] text-white/30 uppercase">ID: {product.id.padStart(4, '0')}</span>
           {product.limitedEdition && (
             <div className="flex items-center gap-2">
                <span className="w-1 h-1 bg-white animate-pulse rounded-full"></span>
                <span className="text-[8px] font-bold tracking-[0.2em] text-white uppercase">One of Fifty</span>
             </div>
           )}
        </div>

        {/* Location-based scarcity ticker */}
        {product.locationStock && (
           <div className="absolute bottom-0 left-0 w-full bg-white/10 backdrop-blur-md py-2 px-4 translate-y-full group-hover:translate-y-0 transition-transform duration-500">
              <p className="text-[8px] font-bold tracking-[0.3em] text-white uppercase">
                 Limited: Only {product.stockCount} remaining in {product.locationStock}.
              </p>
           </div>
        )}

        {/* CTA Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
           <button 
             onClick={() => onAddToCart(product)}
             className="bg-white text-[#050505] px-8 py-4 text-[10px] tracking-[0.5em] font-extrabold uppercase shadow-[0_0_40px_rgba(255,255,255,0.3)] hover:scale-105 transition-all"
           >
             Acquire
           </button>
        </div>
      </div>

      {/* Info */}
      <div className="mt-8 space-y-4 flex flex-col flex-1">
        <div className="flex items-center gap-2">
           <span className="text-[9px] font-bold tracking-[0.4em] text-white/30 uppercase">{product.category}</span>
           <div className="h-[1px] flex-1 bg-white/5"></div>
        </div>
        <div className="flex justify-between items-start">
           <h3 className="font-syncopate text-xl font-bold tracking-tighter platinum-gradient uppercase">{product.name}</h3>
           <span className="text-white text-[14px] font-bold">₹{product.price.toLocaleString()}</span>
        </div>
        
        {/* Description Snippet */}
        <p className="text-[11px] leading-relaxed text-white/40 tracking-wide font-light line-clamp-3">
          {product.description}
        </p>

        <div className="mt-auto">
          <button 
            onClick={handleViewSpecs}
            className="flex items-center gap-2 text-[9px] font-bold tracking-[0.4em] text-white/20 hover:text-white transition-all uppercase group/link"
          >
             View Full Specs <ChevronRight size={12} className="group-hover/link:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
