
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, X, Terminal } from 'lucide-react';
import { ChatMessage } from '../types';
import { getStylistResponse } from '../services/geminiService';

const StylistAI: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', content: "Protocol initiated. I am Lex. How shall we manifest your aesthetic today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const history = [...messages, userMsg];
    const response = await getStylistResponse(history);
    
    setMessages(prev => [...prev, { role: 'model', content: response }]);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-12 right-12 z-[100]">
      {isOpen ? (
        <div className="bg-[#030303] w-80 md:w-[450px] h-[600px] border border-white/10 shadow-[0_0_100px_rgba(255,255,255,0.05)] flex flex-col overflow-hidden animate-fade-in glass">
          {/* Header */}
          <div className="bg-white/5 p-6 flex items-center justify-between border-b border-white/5">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-white rounded-full"></div>
              <span className="text-white text-[10px] tracking-[0.4em] uppercase font-black">Lex_Concierge.AI</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/30 hover:text-white">
              <X size={20} strokeWidth={1} />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-10 custom-scrollbar">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] p-6 text-[13px] leading-relaxed tracking-wide ${
                  m.role === 'user' 
                    ? 'bg-white text-black font-bold uppercase text-[10px] tracking-[0.2em]' 
                    : 'text-white/60 font-light border-l border-white/20 pl-6'
                }`}>
                  {m.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="p-2 flex gap-2">
                  <div className="w-1 h-1 bg-white animate-bounce"></div>
                  <div className="w-1 h-1 bg-white animate-bounce [animation-delay:-.3s]"></div>
                  <div className="w-1 h-1 bg-white animate-bounce [animation-delay:-.5s]"></div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="p-8 border-t border-white/5">
            <div className="flex gap-4">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Query the Lex Protocol..."
                className="flex-1 bg-transparent text-[11px] tracking-[0.2em] border-b border-white/10 focus:border-white outline-none py-2 px-1 text-white placeholder:text-white/10"
              />
              <button onClick={handleSend} className="text-white/40 hover:text-white">
                <Send size={20} strokeWidth={1} />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-white text-black w-16 h-16 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all flex items-center justify-center group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-black scale-y-0 group-hover:scale-y-100 transition-transform duration-500"></div>
          <Terminal size={24} className="relative z-10 group-hover:text-white transition-colors" />
        </button>
      )}
    </div>
  );
};

export default StylistAI;
