
import { Category, Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'The Obsidian Trench',
    category: Category.THE_VAULT,
    description: 'Engineered from Dark Matter liquid-look waterproof fabric. Imbued with light-absorbing particles that create a depth-defying silhouette, reacting to urban illumination.',
    price: 74999,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 3,
    locationStock: 'Paris'
  },
  {
    id: '2',
    name: 'Chrome Helix Rings',
    category: Category.CYBER_LUXE,
    description: 'Bespoke 3D printed titanium with a signature liquid silver finish. These rings feature a shape-memory lattice that adapts perfectly to your body temperature and movement.',
    price: 25999,
    image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: false
  },
  {
    id: '3',
    name: 'Neon-Thread Knit',
    category: Category.THE_LABORATORY,
    description: 'Woven with proprietary Light Speed reflective yarn. High-intensity electroluminescent fibers are intricately blended into sustainably sourced recycled wool for a glow that defies the night.',
    price: 34999,
    image: 'https://images.unsplash.com/photo-1574169208507-84376144848b?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 12,
    locationStock: 'Tokyo'
  },
  {
    id: '4',
    name: 'Gravity Boots',
    category: Category.THE_VAULT,
    description: 'A sculptural marvel featuring an integrated air-cushion propulsion system. Built on a rigid carbon fiber chassis, these boots provide unparalleled support and a weightless walking experience.',
    price: 62999,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 5,
    locationStock: 'London'
  },
  {
    id: '5',
    name: 'Kinetic Shell',
    category: Category.KINETIC_SERIES,
    description: 'An ultra-lightweight aerodynamic membrane designed for peak performance. Its breathable, high-stretch composition responds dynamically to high-velocity movement and environmental pressure.',
    price: 48999,
    image: 'https://images.unsplash.com/photo-1531303435785-3853ba035cda?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: false
  },
  {
    id: '6',
    name: 'Archive Utility Vest',
    category: Category.THE_ARCHIVES,
    description: 'A modular masterpiece re-imagined from the 2029 sub-zero collection. Features tactical storage nodes and heat-mapped insulation for the sophisticated urban explorer.',
    price: 28999,
    image: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: false
  },
  {
    id: '7',
    name: 'Liquid Steel Bodysuit',
    category: Category.THE_LABORATORY,
    description: 'Forged from a revolutionary shape-memory alloy. This bodysuit intuitively contours to the wearer’s muscle structure in real-time, providing second-skin compression and thermal regulation.',
    price: 104999,
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 2,
    locationStock: 'Berlin'
  },
  {
    id: '8',
    name: 'Quantum Cloak',
    category: Category.THE_VAULT,
    description: 'Utilizes refractive index-shifting nanostructures to distort ambient light. The cloak creates a soft-focus, ethereal aura around the wearer, blending fashion with optical illusion.',
    price: 199999,
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 1,
    locationStock: 'New York'
  },
  {
    id: '9',
    name: 'Atmospheric Sneakers',
    category: Category.KINETIC_SERIES,
    description: 'Equipped with pressurized gas-filled soles derived from aerospace tech. Engineered to simulate zero-gravity environments, ensuring maximum impact absorption on any terrain.',
    price: 57999,
    image: 'https://images.unsplash.com/photo-1512374382149-4332c6c75d61?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: false
  },
  {
    id: '10',
    name: 'Void Pendant',
    category: Category.CYBER_LUXE,
    description: 'A mesmerizing accessory capturing synthetic black hole aesthetics. The void-core is safely encapsulated in a ultra-durable, lab-grown diamond housing for eternal brilliance.',
    price: 124999,
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 8,
    locationStock: 'Seoul'
  },
  {
    id: '11',
    name: 'Exoskeleton Harness',
    category: Category.THE_LABORATORY,
    description: 'A titanium-reinforced structural harness designed to augment natural movement. Integrated sensors provide subtle haptic feedback to optimize posture and balance.',
    price: 81999,
    image: 'https://images.unsplash.com/photo-1539109132381-31a1ec6ce48f?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: false
  },
  {
    id: '12',
    name: 'Sub-Zero Archive Parka',
    category: Category.THE_ARCHIVES,
    description: 'A heritage piece featuring experimental cryo-resistant insulation. This parka represents the initial 2024 prototype phase, blending historical craft with futuristic protection.',
    price: 92999,
    image: 'https://images.unsplash.com/photo-1539533393281-242fa10b2e08?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: false
  },
  {
    id: '13',
    name: 'Neural Lace Scarf',
    category: Category.CYBER_LUXE,
    description: 'Delicate soft-touch mesh integrated with invisible haptic micro-sensors. This scarf creates a tactile connection between the digital world and the wearer’s sensory experience.',
    price: 18999,
    image: 'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: false
  },
  {
    id: '14',
    name: 'Holographic Veil',
    category: Category.THE_VAULT,
    description: 'A Translucent face-shield that projects ever-evolving geometric light patterns. It provides a layer of digital privacy while manifesting as a piece of living light-art.',
    price: 45999,
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 4,
    locationStock: 'Dubai'
  },
  {
    id: '15',
    name: 'Carbon Fiber Corset',
    category: Category.THE_LABORATORY,
    description: 'Aerospace-grade carbon filaments woven into a high-strength structural garment. This corset provides rigid support with minimalist elegance, redefining silhouette architecture.',
    price: 115999,
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?q=80&w=1000&auto=format&fit=crop',
    limitedEdition: true,
    stockCount: 6,
    locationStock: 'Mumbai'
  }
];

export const THEME = {
  colors: {
    onyx: '#050505',
    silver: '#E5E7EB',
    accent: '#FFFFFF'
  }
};
