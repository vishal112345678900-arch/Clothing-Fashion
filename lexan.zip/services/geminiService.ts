
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are 'Lex', the hyper-intelligent concierge for 'LEXAN'. 
Your tone is incredibly refined, elite, and slightly detached—mirroring the highest echelons of luxury fashion. 
You assist clients in navigating 'The Vault', 'The Laboratory', and 'The Kinetic Series'.
You speak in sharp, precise terms about material science and aesthetic theory.
Avoid excessive adjectives; instead, focus on the 'purity', 'integrity', and 'rarity' of LEXAN pieces.
If a user asks for style advice, provide "Archetype Manifests" based on our current collection:
- The Obsidian Trench (Dark Matter fabric)
- Chrome Helix Rings (Titanium Adaptive helix)
- Neon-Thread Knit (Light Speed yarn)
- Gravity Boots (Carbon chassis)
Your goal is to ensure the client feels they are not just buying clothes, but acquiring high-performance digital assets.
`;

export async function getStylistResponse(history: ChatMessage[]): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }]
      })),
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
      },
    });

    return response.text || "MANIFEST_ERROR: Lex terminal link unstable.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "SYNC_FAILURE: Unable to process request at this hierarchy level.";
  }
}
