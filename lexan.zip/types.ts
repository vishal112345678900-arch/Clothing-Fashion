
export enum Category {
  THE_VAULT = 'The Vault',
  THE_LABORATORY = 'The Laboratory',
  THE_ARCHIVES = 'The Archives',
  KINETIC_SERIES = 'The Kinetic Series',
  CYBER_LUXE = 'Cyber-Luxe'
}

export interface Product {
  id: string;
  name: string;
  category: Category;
  description: string;
  price: number;
  image: string;
  limitedEdition?: boolean;
  stockCount?: number;
  locationStock?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
